@echo off

for /f "tokens=2,*" %%A in ('java -XshowSettings:properties -version 2^>^&1 ^| findstr "java.home"') do (
    set "JAVA_HOME=%%B"
)

set "CATALINA_HOME=%~dp0servlet"

call "%CATALINA_HOME%\bin\shutdown.bat"

echo Tomcat stopped.
pause