@echo off
title Java Servlet Program

echo ========================================
echo   Starting JSP Servlet Program
echo ========================================
echo.

REM Check Java
java -version >nul 2>&1

if errorlevel 1 (
    echo Java is not installed.
    echo Please install JDK 17 or later.
    pause
    exit /b
)

REM Automatically find JAVA_HOME
for /f "tokens=2,*" %%A in ('java -XshowSettings:properties -version 2^>^&1 ^| findstr "java.home"') do (
    set "JAVA_HOME=%%B"
)

echo Java Home:
echo %JAVA_HOME%
echo.

REM Automatically locate Tomcat
set "CATALINA_HOME=%~dp0servlet"

echo Starting Tomcat...
call "%CATALINA_HOME%\bin\startup.bat"

timeout /t 3 /nobreak >nul

echo Opening browser...
start "" "http://localhost:8080/JavaServletDemo/hello.jsp"

echo.
echo Servlet Program Started Successfully.
pause